// Runs inside the signed package's opaque frame. All persistent values belong to this block.
function mountDotWidget(start, height) {
  const channel = 'life-atlas.widget.v1';
  let revision = -1, sequence = 0, pending = null, dirty = false, locked = false;
  let state = {}, started = false;
  const send = (type, more = {}) => parent.postMessage({ channel, type, ...more }, '*');
  function flush() {
    if (locked || pending !== null || !dirty) return;
    dirty = false;
    pending = ++sequence;
    send('commit', { id: pending, base: revision, state });
  }
  function save(key, value) {
    if (locked || state[key] === value) return;
    const next = { ...state, [key]: value };
    if (new TextEncoder().encode(JSON.stringify(next)).length > 1048576) throw Error('组件记录超过 1 MiB，页面保留了上一次保存的记录。');
    state = next;
    dirty = true;
    flush();
  }
  const storage = { getItem: key => state[key] ?? null, setItem: (key, value) => save(key, String(value)),
    removeItem: key => { if (Object.hasOwn(state, key)) { delete state[key]; dirty = true; flush(); } } };
  window.addEventListener('message', event => {
    const msg = event.data;
    if (event.source !== parent || msg?.channel !== channel || msg.type !== 'context' ||
        !Number.isSafeInteger(msg.revision) || msg.revision < revision) return;
    const ack = pending !== null && msg.ack?.id === pending;
    // An external edit (including Undo) must replace the contents in the widget itself.
    const external = started && msg.revision !== revision && !ack &&
        JSON.stringify(msg.state) !== JSON.stringify(state);
    revision = msg.revision;
    if (external || (ack && !msg.ack.accepted)) {
      location.reload();
      return;
    }
    if (ack) pending = null;
    locked = Boolean(msg.locked);
    document.body.inert = locked;
    if (!started) {
      started = true;
      state = { ...msg.state };
      document.documentElement.dataset.theme = msg.theme;
      start({ storage, save, get: key => state[key], context: msg });
    }
    flush();
    send('height', { height: height || Math.max(260, document.body.scrollHeight) });
  });
  // A sandboxed form has no navigation permission. Dispatch only its local submit handler.
  document.addEventListener('click', event => {
    const button = event.target.closest?.('button, input[type=submit]');
    const form = button?.form;
    if (event.defaultPrevented || button?.type !== 'submit' || !form || button.disabled) return;
    event.preventDefault();
    if (form.reportValidity()) form.dispatchEvent(new SubmitEvent('submit', { bubbles: true, cancelable: true, submitter: button }));
  });
  send('ready');
}

mountDotWidget(({storage,context})=>{
document.getElementById("root").innerHTML="<main class=\"root\"><header class=\"stripe\"><div class=\"brand\"><span aria-hidden=\"true\" class=\"mark\">◫</span>日常刻度 <small class=\"muted\">· 组件评审</small></div><div class=\"actions\"><button id=\"theme\" type=\"button\">浅色</button><button id=\"dataset\" type=\"button\">使用空白日志</button></div></header><section class=\"hero line\"><div><p class=\"kicker mono\">DECISION JOURNAL</p><h1 class=\"heading\">决策复盘</h1><p class=\"intro muted\">记下当时的判断，等结果出现后，再把两边放到一起看。</p></div></section><div class=\"track controls-width\"><span class=\"chip\" id=\"mode\"></span><div class=\"widthbox\"><label for=\"width\">栏宽模拟</label><input id=\"width\" max=\"1000\" min=\"300\" step=\"1\" type=\"range\" value=\"1000\"/><output id=\"width-label\">全宽</output></div></div>\n<div class=\"widget\" id=\"widget\"><div class=\"workbench\"><aside aria-label=\"决策列表\" class=\"index\"><div class=\"line\"><h2>决策记录</h2><button class=\"primary\" id=\"add\" type=\"button\">＋ 记录</button></div><select aria-label=\"筛选决策\" id=\"filter\" style=\"margin-bottom:6px\"><option value=\"all\">全部记录</option><option value=\"due\">待复盘</option><option value=\"pending\">未到期</option><option value=\"done\">已复盘</option></select><div class=\"index-list\" id=\"list\"></div></aside><section aria-label=\"决策对照\" class=\"pane\" id=\"detail\"></section></div></div><p class=\"hint legal\">离线评审稿，不连接 Notion。示例与空白日志分开保存；没有到期通知，打开后会显示待复盘。</p><p class=\"status\" id=\"status\" role=\"status\"></p></main>\n<dialog class=\"sheet\" id=\"record-dialog\"><form id=\"record-form\"><h2>记录一项决策</h2><p class=\"hint\" style=\"margin:0\">保存后保留原判断，不会被复盘覆盖。</p><div class=\"fields\"><label>要做的决定<input maxlength=\"65\" name=\"title\" placeholder=\"例：将周会缩短到 30 分钟\" required=\"\"/></label><label>当时的依据<textarea maxlength=\"1200\" name=\"why\" placeholder=\"为什么选这个方案？关键假设是什么？\" required=\"\"></textarea></label><label>预期结果与验收标准<textarea maxlength=\"1200\" name=\"expect\" placeholder=\"例：两周内全员仍能在会前收到材料，且至少四次会议准时结束\" required=\"\"></textarea></label><div class=\"formrow\"><label>复盘日期<input name=\"due\" required=\"\" type=\"date\"/></label><label>当时的把握<input max=\"100\" min=\"0\" name=\"confidence\" required=\"\" step=\"1\" type=\"number\" value=\"70\"/></label></div></div><div class=\"actions form-actions\"><button data-close=\"record-dialog\" type=\"button\">取消</button><button class=\"primary\" type=\"submit\">保存原判断</button></div></form></dialog>\n<dialog class=\"sheet\" id=\"review-dialog\"><form id=\"review-form\"><h2>记录复盘结果</h2><div class=\"fields\"><label>实际发生了什么<textarea maxlength=\"1600\" name=\"actual\" placeholder=\"写事实、数据或证据\" required=\"\"></textarea></label><label>预期是否达成？<select name=\"verdict\"><option value=\"met\">达成</option><option value=\"part\">部分达成</option><option value=\"miss\">未达成</option><option value=\"unknown\">暂无法判断</option></select></label><label>下次会怎么做<textarea maxlength=\"1600\" name=\"lesson\" placeholder=\"继续、调整或停止？\"></textarea></label></div><div class=\"actions form-actions\"><button data-close=\"review-dialog\" type=\"button\">取消</button><button class=\"primary\" type=\"submit\">保存复盘</button></div></form></dialog>\n";
function atlasConfirm(message) {
      return new Promise(resolve => {
        const dialog = document.createElement('dialog'), text = document.createElement('p');
        text.textContent = message; dialog.append(text);
        for(const [label,value] of [['取消','cancel'],['确认','ok']]){
          const button=document.createElement('button');button.type='button';button.textContent=label;
          button.onclick=()=>dialog.close(value);dialog.append(button);
        }
        dialog.onclose=()=>{resolve(dialog.returnValue==='ok');dialog.remove();};
        document.body.append(dialog);dialog.showModal();
      });
    }

'use strict';
const $=s=>document.querySelector(s);
const el=(tag,cls,txt)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(txt!=null)n.textContent=txt;return n};
const group=(cls,...kids)=>{const n=el('div',cls);n.append(...kids);return n};
const button=(txt,fn,cls)=>{const n=el('button',cls,txt);n.type='button';n.addEventListener('click',fn);return n};
const q=new URLSearchParams({embed:'1'}), embed=q.get('embed')==='1', instance=(q.get('id')||'default').slice(0,64), key='decision-journal-1:'+instance;
const today=(delta=0)=>{const d=new Date;d.setDate(d.getDate()+delta);return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')};
const validateDate=s=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const d=new Date(s+'T00:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===s};
const seed=()=>[
{id:'d1',title:'用一周测试「先做题再看笔记」',why:'重读笔记很顺手，但合上就想不起来。想用练习题先暴露盲点。',expect:'一周后做 20 道同难度题，答对至少 16 道，复习总时长不超过 3 小时。',confidence:68,created:today(-10),due:today(-3),review:{date:today(-2),actual:'做对 17 / 20 道；用时 3 小时 20 分钟。错题集中在同一个知识点。',verdict:'part',lesson:'保留先做题。给题组设 35 分钟上限，留 10 分钟回查高频错误。'}},
{id:'d2',title:'把周会从 45 分钟缩到 30 分钟',why:'过去三次都在会上补背景；提前发两段摘要，讨论可以聚焦决策。',expect:'两次周会都在 30 分钟内结束，且重要议题不延到会后。',confidence:75,created:today(-15),due:today(-1)},
{id:'d3',title:'先做窄栏组件，再做模板合集',why:'用户先能在自己的页面试用，才知道合集里哪些组件值得长期保留。',expect:'一周内请 3 人在不同栏宽试用，至少 2 人愿意保留一个组件。',confidence:60,created:today(-2),due:today(5)}
];
let storageReady=false;try{storage.setItem(key+':test','1');storage.removeItem(key+':test');storageReady=true}catch{}
function get(k,f){try{return JSON.parse(storage.getItem(key+':'+k))??f}catch{return f}}
function put(k,v){try{storage.setItem(key+':'+k,JSON.stringify(v))}catch{storageReady=false}}
let demo=get('mode',context.demonstration), datasets={demo:get('demo',seed()),blank:get('blank',[])}, theme=q.get('theme')||get('theme',context.theme), active=null;
const data=()=>datasets[demo?'demo':'blank'], persist=()=>put(demo?'demo':'blank',data());
const stage=(d,t=today())=>d.review?'done':d.due<=t?'due':'pending';
const stageText={done:'已复盘',due:'待复盘',pending:'未到期'}, verdicts={met:'达成',part:'部分达成',miss:'未达成',unknown:'暂无法判断'};
const dateLabel=(d)=>d.replaceAll('-','.');
function setTheme(t){theme=t==='light'?'light':'dark';document.documentElement.dataset.theme=theme;$('#theme').textContent=theme==='light'?'深色':'浅色';put('theme',theme)}
function notice(s){$('#status').textContent=s}
function render(){
 const records=data(), filter=$('#filter').value, shown=records.filter(d=>filter==='all'||stage(d)===filter);
 if(!shown.some(d=>d.id===active))active=shown[0]?.id??null;
 $('#mode').textContent=demo?'示例日志':'空白日志 · 本地数据';
 $('#dataset').textContent=demo?'使用空白日志':'查看示例';
 const due=records.filter(d=>stage(d)==='due').length;
 $('#list').replaceChildren(...shown.map(d=>{const b=button('',()=>{active=d.id;render();Array.from($('#list').children).find(n=>n.getAttribute('aria-current')==='true')?.focus()});b.setAttribute('aria-current',String(d.id===active));b.append(el('strong','',d.title),el('small','',stageText[stage(d)]+' · '+dateLabel(d.due)));return b}));
 const detail=$('#detail'), d=shown.find(x=>x.id===active);
 if(!d){detail.replaceChildren(el('h2','card-title',records.length?'这个筛选下没有记录':'先记下一个决定'),group('empty',el('p','',records.length?'换个筛选看看。':'写下原因、预期和复盘日期，等结果出现再回来。'),records.length?button('查看全部',()=>{$('#filter').value='all';render()}):button('记录第一项决策',openRecord,'primary')));return}
 const stamp=group('line',el('span','mono muted',dateLabel(d.created)),el('span','tag '+stage(d),stageText[stage(d)]));
 const header=el('h2','card-title',d.title);
 const path=el('div','path');
 const a=el('span'), b=el('span');a.append(el('i','node a'),el('span','','记下判断'));b.append(el('i','node b'+(d.review?' on':'')),el('span','',d.review?'复盘于 '+dateLabel(d.review.date):'计划复盘 '+dateLabel(d.due)));path.append(a,b);
 const before=el('article','paper'), after=el('article','paper');
 const meter=el('span','meter'), fill=el('span');fill.style.width=d.confidence+'%';meter.append(fill);meter.setAttribute('aria-hidden','true');
 before.append(el('div','stamp mono','BEFORE'),el('h3','','当时的判断'),el('h4','','依据'),el('p','',d.why),el('h4','','预期与验收'),el('p','',d.expect),group('confidence',meter,el('span','mono','把握 '+d.confidence+'%')));
 after.append(el('div','stamp mono after','AFTER'),el('h3','','实际与复盘'));
 if(d.review){after.append(el('span','tag '+({met:'done',miss:'bad'}[d.review.verdict]||''),verdicts[d.review.verdict]),el('h4','','发生了什么'),el('p','',d.review.actual));if(d.review.lesson)after.append(el('h4','','下次怎么做'),el('p','',d.review.lesson))}
 else{after.append(group('empty',el('p','',stage(d)==='due'?'到了复盘日。拿实际结果对照左侧的验收标准。':'还未填写实际结果。证据已经有了，也可以提前复盘。')))}
 const tools=group('actions',button(d.review?'更新复盘':'填写复盘',()=>openReview(d),'primary'),button('复制为 Markdown',()=>copy(d)));
 detail.replaceChildren(stamp,header,path,group('comparison',before,after),group('gloss',el('span','',due?'日志有 '+due+' 项待复盘':'当前没有到期未复盘的项目'),tools));
}
function openRecord(){$('#record-form').reset();$('#record-form').elements.due.value=today(7);$('#record-dialog').showModal()}
let target=null;
function openReview(d){target=d.id;const f=$('#review-form');f.reset();if(d.review){f.elements.actual.value=d.review.actual;f.elements.verdict.value=d.review.verdict;f.elements.lesson.value=d.review.lesson}$('#review-dialog').showModal()}
function markdown(d){const rv=d.review;return '# '+d.title+'\n\n- 决策日期：'+d.created+'\n- 计划复盘：'+d.due+'\n- 当时把握：'+d.confidence+'%\n\n## 当时的判断\n\n### 依据\n'+d.why+'\n\n### 预期与验收\n'+d.expect+'\n\n## 实际与复盘\n\n'+(rv?'复盘日期：'+rv.date+'\n\n结果：'+verdicts[rv.verdict]+'\n\n'+rv.actual+(rv.lesson?'\n\n### 下次怎么做\n'+rv.lesson:''):'尚未填写')+'\n'}
async function copy(d){const s=markdown(d);try{await navigator.clipboard.writeText(s);notice('已复制 Markdown。')}catch{const out=el('textarea');out.value=s;out.readOnly=true;out.setAttribute('aria-label','复盘 Markdown');$('#status').replaceChildren(el('span','','选择并复制以下内容：'),out);out.select()}}
function readField(form,n){const input=form.elements[n], s=input.value.trim();if(!s&&input.required){input.setCustomValidity('请填写此项。');input.reportValidity();input.setCustomValidity('');return null}return s}
$('#record-form').addEventListener('submit',e=>{e.preventDefault();const f=e.currentTarget,title=readField(f,'title'),why=readField(f,'why'),expect=readField(f,'expect'),due=f.elements.due.value,confidence=Number(f.elements.confidence.value);
 if(!title||!why||!expect||!validateDate(due)||!Number.isInteger(confidence)||confidence<0||confidence>100)return;
 const record={id:globalThis.crypto?.randomUUID?.()??String(Date.now())+'-'+Math.random(),title,why,expect,due,confidence,created:today()};
 data().unshift(record);active=record.id;persist();$('#filter').value='all';$('#record-dialog').close();notice(storageReady?'已保存原判断。':'已记录；当前浏览器不允许保存，关闭后会丢失。');render()});
$('#review-form').addEventListener('submit',e=>{e.preventDefault();const f=e.currentTarget,d=data().find(x=>x.id===target),actual=readField(f,'actual');if(!d||!actual)return;
 const verdict=f.elements.verdict.value,lesson=f.elements.lesson.value.trim();if(!Object.hasOwn(verdicts,verdict))return;d.review={date:today(),actual,verdict,lesson};persist();$('#filter').value='all';active=d.id;$('#review-dialog').close();notice(storageReady?'已保存复盘。':'已记录；当前浏览器不允许保存，关闭后会丢失。');render()});
for(const b of document.querySelectorAll('[data-close]'))b.onclick=()=>document.getElementById(b.dataset.close).close();
$('#dataset').onclick=()=>{demo=!demo;put('mode',demo);active=null;$('#filter').value='all';notice('');render()};
$('#add').onclick=openRecord;$('#filter').onchange=render;$('#theme').onclick=()=>setTheme(theme==='dark'?'light':'dark');
$('#width').oninput=()=>{const w=Number($('#width').value);$('#widget').style.width=w===1000?'100%':'min(100%, '+w+'px)';$('#width-label').value=w===1000?'全宽':w+' px'};
if(embed)document.documentElement.classList.add('embed');
setTheme(theme);render();

},520);
